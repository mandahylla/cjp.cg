<?php 

define('DBUSER', "root");
define('DBPASS', "");
define('DBNAME', "mychat_db");
define('DBHOST', "Localhost");
