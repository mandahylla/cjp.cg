<?php

require_once("config.php");
require_once("database.php");
